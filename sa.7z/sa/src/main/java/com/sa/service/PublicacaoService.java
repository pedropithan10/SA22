package com.sa.service;

import com.sa.model.Publicacao;

import java.util.List;

public interface PublicacaoService {

    public List<Publicacao> findAll();
    public Publicacao findById(Long id);
    public Publicacao save(Publicacao publicacao);
    public void deleteById(Long id);

}
