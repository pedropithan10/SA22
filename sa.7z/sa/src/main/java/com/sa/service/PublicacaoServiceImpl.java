package com.sa.service;

import com.sa.model.Publicacao;
import com.sa.repository.PublicacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PublicacaoServiceImpl implements PublicacaoService {

    @Autowired
    PublicacaoRepository publicacaoRepository;

    @Override
    public List<Publicacao> findAll() {
        return publicacaoRepository.findAll();
    }

    @Override
    public Publicacao findById(Long id) {
        Publicacao findPublicacao = publicacaoRepository.findById(id).get();
        if (findPublicacao != null) {
            return findPublicacao;
        } else {
            return new Publicacao();
        }
    }

    @Override
    public Publicacao save(Publicacao publicacao) {
        try {
            return publicacaoRepository.save(publicacao);
        } catch (Exception e) {
            throw (e);
        }
    }

    @Override
    public void deleteById(Long id) {
        try {
            publicacaoRepository.deleteById(id);
        } catch (Exception e) {
            throw e;
        }
    }

}
