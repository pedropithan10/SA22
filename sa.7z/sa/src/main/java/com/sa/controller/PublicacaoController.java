package com.sa.controller;

import com.sa.model.Publicacao;
import com.sa.service.ClienteServiceImpl;
import com.sa.service.PublicacaoServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PublicacaoController {

    @Autowired
    PublicacaoServiceImpl publicacaoService;

    @Autowired
    ClienteServiceImpl clienteService;


    @GetMapping("/publicacao/list")
    public String findAll(Model model){
        model.addAttribute("publicacoes", publicacaoService.findAll());
        return "publicacao/list";
    }

    @GetMapping("/publicacao/add")
    public String add(Model model){
        model.addAttribute("evento", new Publicacao());
        model.addAttribute("clientes", clienteService.findAll());
        return "publicacao/add";
    }

    @GetMapping("/publicacao/edit/{id}")
    public String edit(Model model, @PathVariable long id){
        model.addAttribute("publicacao", publicacaoService.findById(id));
        model.addAttribute("clientes", clienteService.findAll());
        return "publicacao/edit";
    }

    @PostMapping("/publicacao/save")
    public String save(Publicacao publicacao, Model model){
        try{
            System.out.println("Publicacao" + publicacao);
            Publicacao newpublicacao = publicacaoService.save(publicacao);
            model.addAttribute("publicacao", newpublicacao);
            model.addAttribute("isSave", true);
            model.addAttribute("isError", false);
            model.addAttribute("clientes", clienteService.findAll());
            return "/publicacao/add";
        }catch (Exception e){
            model.addAttribute("publicacao", publicacao);
            model.addAttribute("isSave", false);
            model.addAttribute("isError", true);
            model.addAttribute("clientes", clienteService.findAll());
            return "/publicacao/add";
        }
    }
    @GetMapping("/publicacao/delete/{id}")
    public String delete(@PathVariable long id){
        try{
            publicacaoService.deleteById(id);
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
        return "redirect:/publicacao/list";
    }

}
